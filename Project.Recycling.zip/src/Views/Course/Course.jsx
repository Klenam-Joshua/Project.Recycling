import { useParams } from "react-router-dom";
import useFetch from "../../hooks/useFetch";
import TopBanner from "../../Layout/TopBanner/TopBanner";
import { Col, Row } from "reactstrap";

import ContentLoader from "react-content-loader";

import { UPDATE_VIDEO_PROGRESS } from "../../Endpoints/GameEndpoints";

import ReactPlayer from "react-player";
import { usePut } from "../../hooks/usePut";
import { useEffect, useState } from "react";
import { useAuth } from "../../hooks/useAuth";

const _videos = [
  {
    videoName: "LEVEL 1",
    minutes: "14min",
  },
  {
    videoName: "LEVEL 1",
    minutes: "14min",
  },
  {
    videoName: "LEVEL 1",
    minutes: "14min",
  },
  {
    videoName: "LEVEL 1",
    minutes: "14min",
  },
  {
    videoName: "LEVEL 1",
    minutes: "14min",
  },
  {
    videoName: "LEVEL 1",
    minutes: "14min",
  },
  {
    videoName: "LEVEL 1",
    minutes: "14min",
  },
];
export default function Course() {
  const param = useParams();
  const [currentVideo, setCurrentVideo] = useState({});
  const [timeoutId, setTimeOutId] = useState(null);
  const { auth } = useAuth();

  const { data: video, isLoading } = useFetch(`video/${param.id}`, [param?.id]);

  const { mutate } = usePut(`video/${param.id}`, [param?.id]);

  console.log({ video });

  console.log(currentVideo);
  useEffect(() => {
    const firstVideo = video?.items[0];
    console.log({ firstVideo });
    setCurrentVideo({
      ...firstVideo,
      indx: 0,
      url: firstVideo?.videourl,
      isCompleted: firstVideo?.progress?.isCompleted,
    });
  }, [video]);

  return (
    <div>
      <TopBanner
        title="Recycling Courses"
        description="Select  a video to watch"
      />
      <div className="">
        <div
          style={{
            margin: "auto",
            width: "95%",
          }}
        >
          <Row
            style={{
              paddingInline: "0",
            }}
          >
            <Col md="8">
              <div>
                <div
                  // className="border-3  border "
                  style={{
                    // border: "3px solid black",
                    height: "30rem",
                  }}
                >
                  {!currentVideo.videourl && (
                    <div
                      className="d-flex align-items-center justify-content-center"
                      style={{
                        height: "100%",
                        width: "100%",
                      }}
                    >
                      <div style={{ fontWeight: "bold" }}>
                        No video to display yet
                      </div>
                    </div>
                  )}
                  {currentVideo.videourl && (
                    <ReactPlayer
                      onEnded={() => {
                        const nextVideo = video?.items[currentVideo?.indx + 1];
                        if (nextVideo) {
                          setCurrentVideo((prev) => ({
                            ...prev,
                            indx: prev?.indx + 1,
                            url: nextVideo.videourl,
                            isCompleted: nextVideo.progress?.isCompleted,
                          }));
                        }
                      }}
                      onProgress={(progress) => {
                        const { loaded, loadedSeconds, played, playedSeconds } =
                          progress;
                        if (!currentVideo?.isCompleted) {
                          const percentagePlayed = played * 100;
                          console.log({ percentagePlayed });

                          const isCompleted =
                            percentagePlayed >= 97 ? true : undefined;
                          if (timeoutId) {
                            clearTimeout(timeoutId);
                          }

                          const id = setTimeout(() => {
                            mutate({
                              data: {
                                progress: percentagePlayed,
                                userId: auth?._id,
                                videoId: currentVideo?._id,
                                isCompleted,
                              },
                              url: UPDATE_VIDEO_PROGRESS(),
                            });
                          }, 4000);
                          setTimeOutId(id);
                        }
                      }}
                      playing={true}
                      controls={true}
                      height={"100%"}
                      width={"100%"}
                      url={currentVideo.videourl}
                    />
                  )}
                </div>
              </div>
            </Col>
            <Col md="4">
              <div
                className="bg-white mt-3 px-1 py-2"
                style={{
                  height: "40rem",
                  overflow: "auto",
                }}
              >
                {isLoading && <MyLoader />}
                {!isLoading &&
                  video?.items?.map((video, id) => {
                    return (
                      <div
                        className={`${
                          currentVideo.url === video.videourl
                            ? "bg-white  py-3 px-3  course-video active-video"
                            : "bg-white  py-3 px-3  course-video"
                        }`}
                        key={id}
                        onClick={() => {
                          setCurrentVideo({
                            ...video,
                            url: video.videourl,
                            isCompleted: video.progress?.isCompleted,
                            indx: id,
                          });
                        }}
                      >
                        <div
                          className="d-flex align-items-center"
                          style={{
                            fontWeight: 400,
                            gap: "1rem",
                            cursor: "pointer",
                          }}
                        >
                          <div>
                            <input
                              checked={video.progress?.isCompleted}
                              type="checkbox"
                              style={{
                                height: "1rem",
                                width: "1rem",
                              }}
                            />
                          </div>
                          <div className="d-flex">
                            <div>{id + 1}.</div>
                            <div>{video.videoTitle}</div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </Col>
          </Row>
        </div>
      </div>
    </div>
  );
}

const MyLoader = (props) => (
  <ContentLoader
    speed={2}
    width={340}
    height={84}
    viewBox="0 0 340 84"
    backgroundColor="#f3f3f3"
    foregroundColor="#ecebeb"
    {...props}
  >
    <rect x="0" y="0" rx="3" ry="3" width="67" height="11" />
    <rect x="76" y="0" rx="3" ry="3" width="140" height="11" />
    <rect x="127" y="48" rx="3" ry="3" width="53" height="11" />
    <rect x="187" y="48" rx="3" ry="3" width="72" height="11" />
    <rect x="18" y="48" rx="3" ry="3" width="100" height="11" />
    <rect x="0" y="71" rx="3" ry="3" width="37" height="11" />
    <rect x="18" y="23" rx="3" ry="3" width="140" height="11" />
    <rect x="166" y="23" rx="3" ry="3" width="173" height="11" />
  </ContentLoader>
);
