import Box from "../assets/images/Rubbishes/Box.png";
import CanDrink from "../assets/images/Rubbishes/CanDrink.png";
import EggShell from "../assets/images/Rubbishes/Egg.png";
import Paper from "../assets/images/Rubbishes/Paper.png";
import PlasticBottle from "../assets/images/Rubbishes/PlasticBottle.png";

export { Box, CanDrink, EggShell, Paper, PlasticBottle };
