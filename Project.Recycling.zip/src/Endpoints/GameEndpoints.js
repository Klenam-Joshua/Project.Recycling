const GET_GAMES = () => "/games";
const GET_GAME_LEVELS = (id) => `/levels/${id}`;
const UPDATE_GAME_PROGRESS = () => `/progress`;

const UPDATE_VIDEO_PROGRESS = () => `/video-progress`;
//  const GET_GAMES =  () => "/games",
//  const GET_GAMES =  () => "/games",

export {
  GET_GAMES,
  GET_GAME_LEVELS,
  UPDATE_GAME_PROGRESS,
  UPDATE_VIDEO_PROGRESS,
};
