import Image1 from "../../assets/images/game1.webp";
import Image2 from "../../assets/images/game2.webp";
import Image3 from "../../assets/images/game3.webp";
import GamePad from "../../assets/images/GamePad.svg";
import DragAndDrop from "../../assets/images/Draganddrop.jpeg";
import Epuzzle from "../../assets/images/EPuzzle.webp";
import TimeTravel from "../../assets/images/TimeTravel.webp";

export { Image1, Image2, Image3, GamePad, DragAndDrop, Epuzzle, TimeTravel };
