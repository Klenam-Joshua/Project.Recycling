import { games } from "../../../utils/genericData";
import { AllGameLevels } from "./LevelIndex";

//styles

// import { Leve1, Level2, Level3 } from "./SortingGame/Levels/Index";

export default function GameLevel({ gameId, level }) {
  return (
    <div>
      <RenderLevel gameId={gameId} level={level} />
    </div>
  );
}

const RenderLevel = ({ gameId, level }) => {
  const activeGame = AllGameLevels.find((game) => game.gameId === gameId);
  console.log({ activeGame, level });
  const LevelComponent = activeGame.levels?.[level] || NoLevelComp;
  console.log({ LEVEL: activeGame.levels });
  return <LevelComponent />;
};

const NoLevelComp = () => <p>Coming soon</p>;
