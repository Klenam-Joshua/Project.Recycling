export default function Level2() {
  return <div>Level2</div>;
}
