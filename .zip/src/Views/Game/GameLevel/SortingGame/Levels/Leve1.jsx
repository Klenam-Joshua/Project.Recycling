// import dustBinDark from "../../../../../assets/images/dustBinDark.";

//components

import PointModal from "../../../../../components/reusables/Data/Modals/PointModal";

//
import { useEffect, useRef, useState } from "react";
import Dustbins from "../Dustins/Dustbins";
import { rubbishes } from "../../../../../utils/genericData";

import "./style.css";
import { useNavigate } from "react-router-dom";

export default function Leve1() {
  const [counter, setCounter] = useState(0);
  const [openPointsModal, setOpenPointsModal] = useState(false);
  const [trialsCount, setTrialsCount] = useState(0);
  const [pointsData, setPointsData] = useState({
    pointsCount: 0,
  });

  const navigate = useNavigate();

  const beingDragRef = useRef(null);

  const handleOnRubbishDrop = (dustbin, e) => {
    e.preventDefault();

    if (rubbishes[counter].type !== dustbin.type) {
      return;
    }

    beingDragRef.current?.classList.remove("scale");
    setPointsData((prev) => ({ ...prev, pointsCount: prev.pointsCount + 1 }));
    // console.log({ counter, RubbishesLength: rubbishes.length });
    if (counter >= rubbishes.length - 1) {
      // alert("limit reached");
      setOpenPointsModal(true);
      //
      return setCounter(0);
    }
    setCounter((prev) => (prev += 1));

    /**
     *
     * if rubbish dumped is the one required for the particular
     * dusbin,  increase point by 1;
     */
  };

  const handleOnDrag = (beingDraged, e) => {
    console.log({ beingDraged });
  };

  // useEffect(() => {
  //   beingDragRef.current.classList.add("scale");
  // }, [counter]);

  const handleCloseModal = () => {
    // set;
    setOpenPointsModal(false);
  };
  return (
    <div>
      <div
        style={{
          width: "fit-content",
          margin: "auto",
        }}
        className="bg-warning rounded  px-2 py-1"
      >
        <span style={{ fontWeight: "bold" }}>Points Earned: </span>
        {pointsData.pointsCount}
      </div>
      <div id="games_wrapper_main" className="pt-4">
        <div>
          <Dustbins {...{ handleOnRubbishDrop }} />

          <div ref={beingDragRef} id="rubbish" className="rounded mt-5   ">
            <div
              draggable={true}
              onDrag={(e) => {
                handleOnDrag(rubbishes[counter]);
              }}
            >
              <img
                // draggable={true}
                src={rubbishes[counter]?.image}
                style={{
                  height: "13rem",
                  width: "80%",
                  display: "block",
                  margin: "auto",
                }}
              />
            </div>
          </div>
        </div>
        {/* <div id="games_trolley"></div> */}
      </div>
      <PointModal
        {...{ openModal: openPointsModal, handleOnClose: handleCloseModal }}
      />
    </div>
  );
}
