import { SortingGameLevels } from "./SortingGame/Levels/Index";

export const AllGameLevels = [{ ...SortingGameLevels }];
