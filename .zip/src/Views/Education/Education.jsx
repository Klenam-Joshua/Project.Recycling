export default function Education() {
  return <div>Education</div>;
}
