import { Button, Modal, ModalBody, ModalFooter, ModalHeader } from "reactstrap";
import Confetti from "react-confetti";
import Trophy from "../../../../assets/images/trophy.png";

import { useWindowSize } from "react-use";
export default function PointModal({
  openModal,
  handleOnClose,
  badgeTitle,
  badgeImage,
}) {
  const { width, height } = useWindowSize();
  return (
    <div>
      <Modal
        isOpen={openModal}
        backdrop
        onClosed={handleOnClose}
        unmountOnClose
      >
        <ModalHeader>
          <p>Congratulations</p>
          <span
            style={{
              fontWeight: "400",
            }}
          >
            You&apos;ve earned a batch for completing this Level
          </span>
        </ModalHeader>

        {/* className="bg-danger" */}
        <ModalBody>
          <div>
            <img
              src={Trophy}
              alt=""
              style={{
                display: "block",
                margin: "auto",
                width: "15rem",
                height: "15rem",
              }}
            />
          </div>
        </ModalBody>
        <ModalFooter>
          <Button onClick={handleOnClose}>Close</Button>
        </ModalFooter>
      </Modal>
      {openModal && <Confetti {...{ width, height, run: openModal }} />}
    </div>
  );
}
