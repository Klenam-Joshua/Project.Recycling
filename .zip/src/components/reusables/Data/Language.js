export const Languages = {
  Game: [
    {
      language: "en",
      trans: "Game",
    },
    {
      language: "fr",
      trans: "Jeu",
    },
  ],
  "Select Level": [
    {
      language: "en",
      trans: "Select Level",
    },
    {
      language: "fr",
      trans: "Jeu",
    },
  ],
};
