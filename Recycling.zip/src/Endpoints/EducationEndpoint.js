const SAVE_ANSWER = () => "/answer";
//  const GET_GAMES =  () => "/games",
//  const GET_GAMES =  () => "/games",

export { SAVE_ANSWER };
