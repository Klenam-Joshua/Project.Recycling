import { useEffect, useRef, useState } from "react";
import {
  APIProvider,
  Map,
  AdvancedMarker,
  Pin,
  useMap,
} from "@vis.gl/react-google-maps";

const { VITE_APP_GOOGLE_MAP_API_KEY } = import.meta.env;

const recycleLocations = [
  {
    key: "manlyBeach",
    name: "Manly Beach",
    location: { lat: -33.8209738, lng: 151.2563253 },
  },
  {
    key: "hyderPark",
    name: "Hyder Park",
    location: { lat: -33.8690081, lng: 151.2052393 },
  },

  {
    key: "botanicGardens",
    name: "Botanic Gardens",
    location: { lat: -33.864167, lng: 151.216387 },
  },
];

export default function Location() {
  const [userLocation, setUserLocation] = useState(null);
  const mapRef = useRef(null);
  const directionsRendererRef = useRef(null);

  useEffect(() => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        });
      },
      (err) => {
        console.error("Failed to get user location", err);
      }
    );
  }, []);

  const handleMarkerClick = async (destination) => {
    if (!userLocation || !mapRef.current) return;

    const directionsService = new window.google.maps.DirectionsService();

    directionsService.route(
      {
        origin: userLocation,
        destination,
        travelMode: window.google.maps.TravelMode.DRIVING,
      },
      (result, status) => {
        if (status === "OK" && result) {
          if (!directionsRendererRef.current) {
            directionsRendererRef.current =
              new window.google.maps.DirectionsRenderer();
            directionsRendererRef.current.setMap(mapRef.current);
          }
          directionsRendererRef.current.setDirections(result);
        } else {
          console.error("Directions request failed", result);
        }
      }
    );
  };

  return (
    <APIProvider apiKey={VITE_APP_GOOGLE_MAP_API_KEY}>
      <Map
        ref={mapRef}
        style={{ height: "100vh", width: "100%" }}
        defaultCenter={{ lat: -33.86, lng: 151.21 }}
        defaultZoom={12}
        gestureHandling="greedy"
        disableDefaultUI={true}
        onLoad={(map) => (mapRef.current = map)}
      >
        {userLocation && (
          <AdvancedMarker position={userLocation}>
            <Pin background="#34A853" borderColor="#000" glyphColor="#fff" />
          </AdvancedMarker>
        )}

        {recycleLocations.map((loc) => (
          <AdvancedMarker
            key={loc.key}
            position={loc.location}
            onClick={() => handleMarkerClick(loc.location)}
          >
            <Pin background="red" glyphColor="#000" borderColor="#000" />
          </AdvancedMarker>
        ))}
      </Map>
    </APIProvider>
  );
}
