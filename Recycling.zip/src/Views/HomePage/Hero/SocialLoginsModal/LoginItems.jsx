const LoginItems = () => {
  return (
    <p></p>
    // <div className={style.container}>
    //   <h2>Sign In</h2>
    //   <form>
    //     <input type="text" placeholder="Username" required />
    //     <input type="password" placeholder="Password" required />
    //     <div className={style.remember}>
    //       <input type="checkbox" id="remember" />
    //       <label htmlFor="remember">Remember me</label>
    //     </div>
    //     <button type="submit">Sign In</button>
    //   </form>
    //   <div className={style.diver}>
    //     <span>OR</span>
    //   </div>
    //   <div className={style.socialsignin}>
    //     <button>
    //       <img src="apple-logo.png" alt="Apple" />
    //       Sign in with Apple
    //     </button>
    //     <button>
    //       <img src="google-logo.png" alt="Google" />
    //       Sign in with Google
    //     </button>
    //   </div>
    //   <a href="#" className={style.helplink}>
    //     Need help signing in?
    //   </a>
    // </div>
  );
};
export default LoginItems;
