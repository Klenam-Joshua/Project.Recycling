import { Table } from "reactstrap";
import { useTable } from "react-table";
import { useMemo } from "react";

export default function EnrolmentTable({ items }) {
  const columns = useMemo(
    () => [
      {
        Header: "Item Name",
        accessor: "itemName",
      },
      {
        Header: "Date",
        accessor: (row) => new Date(row.createdAt).toLocaleDateString(), // 👈 Format the date here
        id: "createdAt", // 👈
      },
    ],
    []
  );

  const { getTableBodyProps, getTableProps, rows, prepareRow, headerGroups } =
    useTable({
      columns,
      data: items,
    });

  return (
    <div
      style={{
        height: "12rem",
        overflow: "auto",
      }}
    >
      <Table hover={true} {...getTableProps()}>
        <thead>
          {headerGroups.map((headerGroup, key) => (
            <tr {...headerGroup.getHeaderGroupProps()} key={`group_${key}`}>
              {headerGroup.headers.map((column, indx) => (
                <th {...column.getHeaderProps()} key={`column__${indx}`}>
                  {column.render("Header")}
                </th>
              ))}
            </tr>
          ))}
        </thead>

        <tbody {...getTableBodyProps()}>
          {rows.map((row, key) => {
            prepareRow(row);
            return (
              <tr {...row.getRowProps()} key={`tr_body_${key}`}>
                {row.cells.map((cell, key) => (
                  <td {...cell.getCellProps()} key={`td_data_${key}`}>
                    {cell.render("Cell")}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </Table>
    </div>
  );
}
