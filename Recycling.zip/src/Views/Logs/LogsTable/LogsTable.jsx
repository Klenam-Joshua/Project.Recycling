// import { Button, Modal, ModalBody, ModalFooter, ModalHeader } from "reactstrap";
import {
  Button,
  Col,
  Label,
  Modal,
  ModalBody,
  ModalFooter,
  ModalHeader,
  Row,
} from "reactstrap";

import { Formik } from "formik";
import { useAuth } from "../../../hooks/useAuth";
import useFetch from "../../../hooks/useFetch";
import EnrolmentTable from "./Table";
import { usePost } from "../../../hooks/usePost";
import toast from "react-hot-toast";
import { useState } from "react";

export default function LogsTable() {
  const [openLogModal, setOpenLogModal] = useState(false);
  const { auth } = useAuth();
  const { isFetching, data: log } = useFetch("logs", [`${auth._id}_logs`]);
  //   usePost

  const handleCloseLogModal = () => {
    setOpenLogModal(false);
  };

  return (
    <div>
      <div className="d-flex">
        <Button
          onClick={() => {
            setOpenLogModal(true);
          }}
        >
          Add Log
        </Button>
      </div>
      {isFetching ? (
        <p>Loading logs...</p>
      ) : (
        <EnrolmentTable items={log?.items || []} />
      )}
      <LogModal closeModal={handleCloseLogModal} openModal={openLogModal} />
    </div>
  );
}

const LogModal = ({ openModal, closeModal }) => {
  const { mutate, isLoading } = usePost(() => {
    // setHasAnswered(true);
    toast.success("Added successfully");
  });
  return (
    <Modal isOpen={openModal} onClosed={closeModal}>
      <Formik
        initialValues={{ itemName: "", recycleDate: "" }}
        validate={(values) => {
          const errors = {};

          if (!values.itemName) {
            errors.itemName = "required ";
          }
          if (!values.recycleDate) {
            errors.recycleDate = "required ";
          }

          return errors;
        }}
        onSubmit={(values, { setSubmitting }) => {
          console.log({ logged: "true" });
          mutate({
            data: { createdAt: values.recycleDate, itemName: values.itemName },
            url: "logs",
          });
          // handleLogin(values);
          // setTimeout(() => {
          //   alert(JSON.stringify(values, null, 2));
          //   setSubmitting(false);
          // }, 400);
        }}
      >
        {({
          values,
          errors,
          touched,
          handleChange,
          handleBlur,
          handleSubmit,
          isSubmitting,
          /* and other goodies */
        }) => (
          <>
            <form onSubmit={handleSubmit}>
              <ModalHeader>Log Recycled Item</ModalHeader>
              <ModalBody>
                <Row>
                  <Col md="12" lg="12">
                    <Label> Item</Label>

                    <input
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.itemName}
                      name="itemName"
                      className="form-control"
                      type="itemName"
                      placeholder="Enter itemName"
                      required
                    />
                    <span className="text-danger">
                      {errors.itemName && touched.itemName && errors.itemName}
                    </span>
                  </Col>
                </Row>
                <Row className="mt-2">
                  <Col md="12" lg="12">
                    <Label>Recycle Date</Label>
                    <input
                      max={new Date().toISOString().split("T")[0]}
                      type="date"
                      name="recycleDate"
                      onChange={handleChange}
                      onBlur={handleBlur}
                      value={values.recycleDate}
                      className="form-control"
                      placeholder="Enter recycle date"
                      required
                    />

                    <span className="text-danger">
                      {errors.recycleDate &&
                        touched.recycleDate &&
                        errors.recycleDate}
                    </span>
                  </Col>
                </Row>

                {/* <Row className="mt-2">
                  <Col>
                    <div
                      className="d-flex "
                      style={{
                        gap: "1rem",
                      }}
                    >
                      <span>Don&apos;t have an account?</span>
                      <span
                        className="text-info"
                        style={{
                          cursor: "pointer",
                        }}
                        role="btn"
                        onClick={() => {
                          setIsLogin(false);
                        }}
                      >
                        Sign up
                      </span>
                    </div>
                  </Col>
                </Row> */}

                {/* <div className={style.diver}>
                    <span>OR</span>
                  </div> */}

                {/* <button type="submit" disabled={isSubmitting}>
                    Submit
                  </button> */}
              </ModalBody>
              <ModalFooter>
                <Button onClick={closeModal}>Cancel</Button>
                <Button disabled={isLoading} color="primary" type="submit">
                  Submit
                </Button>
              </ModalFooter>
            </form>
          </>
        )}
      </Formik>
    </Modal>
  );
};
