import {
  NavItem,
  Nav,
  NavLink,
  TabContent,
  TabPane,
  Card,
  CardText,
  CardTitle,
  Button,
  Row,
  Col,
} from "reactstrap";
import TopBanner from "../../Layout/TopBanner/TopBanner";
import { useState } from "react";
import LogsTable from "./LogsTable/LogsTable";
import BarChartComponent from "./Chart";

export default function Logs() {
  const [activeTab, setActiveTab] = useState(1);

  return (
    <div className="px-2">
      <TopBanner
        title="Recycling Games"
        description="Select recycling game to play"
      />
      <div className="mt-3">
        <Nav tabs>
          <NavItem>
            <NavLink
              className={activeTab === 1 ? "active" : ""}
              onClick={() => setActiveTab(1)}
              style={{ cursor: "pointer" }}
            >
              Recycle Logs
            </NavLink>
          </NavItem>
          <NavItem>
            <NavLink
              className={activeTab === 2 ? "active" : ""}
              onClick={() => setActiveTab(2)}
              style={{ cursor: "pointer" }}
            >
              Logs
            </NavLink>
          </NavItem>
        </Nav>

        <TabContent className="mt-2" activeTab={activeTab}>
          <TabPane tabId={1}>
            <div>
              <BarChartComponent />
            </div>
          </TabPane>
          <TabPane tabId={2}>
            <LogsTable />
          </TabPane>
        </TabContent>
      </div>
    </div>
  );
}
