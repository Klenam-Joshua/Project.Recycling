import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
} from "chart.js";
import { useAuth } from "../../hooks/useAuth";
import useFetch from "../../hooks/useFetch";
import { useEffect, useState } from "react";

// Register chart components
ChartJS.register(BarElement, CategoryScale, LinearScale, Tooltip, Legend);

export default function BarChartComponent() {
  const { auth } = useAuth();
  const { isFetching, data: response } = useFetch("logs", [`${auth._id}_logs`]);

  const [options, setOptions] = useState({});
  const [data, setData] = useState({});

  useEffect(() => {
    if (!response || response?.items?.length === 0) return;

    const itemCounts = response?.items?.reduce((acc, item) => {
      acc[item.itemName] = (acc[item.itemName] || 0) + 1;
      return acc;
    }, {});

    const labels = Object.keys(itemCounts);
    const values = Object.values(itemCounts);

    setData({
      labels,
      datasets: [
        {
          label: "Item Frequency",
          data: values,
          backgroundColor: "#36A2EB",
          borderRadius: 5,
        },
      ],
    });

    setOptions({
      responsive: true,
      plugins: {
        legend: {
          display: true,
          position: "top",
        },
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            precision: 0,
          },
        },
      },
    });
  }, [response]);

  return (
    <div style={{ width: "500px", margin: "0 auto" }}>
      {!isFetching && data?.labels ? (
        <Bar data={data} options={options} />
      ) : (
        <p>Loading chart...</p>
      )}
    </div>
  );
}
